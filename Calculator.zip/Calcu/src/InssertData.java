import java.sql.*;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

public class InssertData {

    public static void main(String[] args) {
        new MyUi();
    }

}

class MyUi extends JFrame {

    private JTextField tf[] = new JTextField[4];
    private JLabel lbl[] = new JLabel[4];
    private int x = 300;
    private int y = 50;
    private int width = 150;
    private int height = 30;
    private String lblText[] = {"ID", "Name", "Age", "Address"};

    MyUi() {
        setSize(500, 500);
        setLayout(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocation(200, 100);

        JLabel heading = new JLabel();
        heading.setBounds(200, 10, 400, 30);
        heading.setText("<html><h1 style='color:black'>Add User</h1></html>");
        add(heading);

        for (int i = 0; i < tf.length; i++) {
            tf[i] = new JTextField();
            tf[i].setBounds(x, y, width, height);

            lbl[i] = new JLabel();
            lbl[i].setBounds(x - 250, y, width, height);
            lbl[i].setText(lblText[i]);

            y += 40;

            add(lbl[i]);
            add(tf[i]);
        }

        JButton save = new JButton("SAVE");
        save.setBounds(180, 240, width, height);
        add(save);

        try {
            Connection connection = CreateConnection.getConnection();

            Statement stmt = connection.createStatement();
           // stmt.executeUpdate();

            //JOptionPane.showMessageDialog(null, "Table created successfully ");
            save.addActionListener(e -> {
                if (isFieldEmpty()) {
                    showMessage("Plese fill all the fields");
                } else if (!isAnInteger()) {
                    showMessage("Id and Age field must be an Integer");
                } else {
                    try {
                        String query = "INSERT INTO REGISTRATION(" + tf[0].getText() + ",'" + tf[1].getText() + "'," + tf[2].getText() + ",'" + tf[3].getText() + "')";

                        // String query="INSERT INTO USERS VALUES(1,'ram',18,'Delhi')";
                        boolean execute = stmt.execute(query);
                        if (!execute) {
                            showMessage("User added successfully. Please check your Database");
                        } else {
                            showMessage("Something went wrong");
                        }
                    } catch (SQLException ex) {
                        showMessage(ex.getMessage());
                    }
                }
            });

        } catch (ClassNotFoundException | SQLException ex) {
            showMessage(ex.getMessage());
        }

        setVisible(true);
    }

    private boolean isAnInteger() {
        boolean b;

        try {
            //if field contain text then throw an exception
            Integer.parseInt(tf[0].getText());
            Integer.parseInt(tf[2].getText());
            b = true;
        } catch (NumberFormatException ex) {
            b = false;
        }
        return b;
    }

    private boolean isFieldEmpty() {
        boolean b = true;
        for (int i = 0; i < tf.length; i++) {
            if (tf[i].getText().isEmpty()) {
                b = true;
            } else {
                b = false;
            }
        }
        return b;
    }

    private void showMessage(String msg) {
        JOptionPane.showMessageDialog(null, msg);
    }
}

class CreateConnection {

    public static Connection getConnection() throws SQLException, ClassNotFoundException {
        Class.forName("com.mysql.cj.jdbc.Driver");
        return DriverManager.getConnection("jdbc:mysql://localhost:3306/scriet", "root", "Please@1997");

    }
}
